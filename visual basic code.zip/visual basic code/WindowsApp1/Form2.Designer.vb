﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class decryptionform
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.DataGridView3 = New System.Windows.Forms.DataGridView()
        Me.keyinhex = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.DataGridView2 = New System.Windows.Forms.DataGridView()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.keyforsbox = New System.Windows.Forms.TextBox()
        Me.cyphertext = New System.Windows.Forms.TextBox()
        Me.textinbinary = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.hexaofxor = New System.Windows.Forms.TextBox()
        Me.leftrotatedstring = New System.Windows.Forms.TextBox()
        Me.totalones = New System.Windows.Forms.TextBox()
        Me.prevrighttoleft = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.xorof2halves = New System.Windows.Forms.TextBox()
        Me.righthalf = New System.Windows.Forms.TextBox()
        Me.lefthalf = New System.Windows.Forms.TextBox()
        Me.keyinbinary = New System.Windows.Forms.TextBox()
        Me.keyinput = New System.Windows.Forms.TextBox()
        Me.plaintext = New System.Windows.Forms.TextBox()
        CType(Me.DataGridView3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label22.Location = New System.Drawing.Point(810, 238)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(69, 13)
        Me.Label22.TabIndex = 148
        Me.Label22.Text = "inverse s-box"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label21.Location = New System.Drawing.Point(365, 238)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(32, 13)
        Me.Label21.TabIndex = 147
        Me.Label21.Text = "s-box"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label19.Location = New System.Drawing.Point(1146, 76)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(66, 13)
        Me.Label19.TabIndex = 146
        Me.Label19.Text = "text in binary"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label16.Location = New System.Drawing.Point(1161, 44)
        Me.Label16.Name = "Label16"
        Me.Label16.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.Label16.Size = New System.Drawing.Size(66, 13)
        Me.Label16.TabIndex = 145
        Me.Label16.Text = "key in binary"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label13.Location = New System.Drawing.Point(705, 105)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(55, 13)
        Me.Label13.TabIndex = 144
        Me.Label13.Text = "key in hex"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle))
        Me.Label20.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label20.Location = New System.Drawing.Point(-1, 133)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(163, 20)
        Me.Label20.TabIndex = 138
        Me.Label20.Text = "S_BOX Generation"
        '
        'Button3
        '
        Me.Button3.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold)
        Me.Button3.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Button3.Location = New System.Drawing.Point(58, 281)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(140, 62)
        Me.Button3.TabIndex = 136
        Me.Button3.Text = "Decrypt"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'DataGridView3
        '
        Me.DataGridView3.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.DataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView3.Location = New System.Drawing.Point(813, 254)
        Me.DataGridView3.Name = "DataGridView3"
        Me.DataGridView3.Size = New System.Drawing.Size(439, 370)
        Me.DataGridView3.TabIndex = 135
        '
        'keyinhex
        '
        Me.keyinhex.Location = New System.Drawing.Point(768, 102)
        Me.keyinhex.Name = "keyinhex"
        Me.keyinhex.Size = New System.Drawing.Size(310, 20)
        Me.keyinhex.TabIndex = 134
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle))
        Me.Label15.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label15.Location = New System.Drawing.Point(1113, 223)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(99, 16)
        Me.Label15.TabIndex = 133
        Me.Label15.Text = "Hex to binary"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle))
        Me.Label14.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label14.Location = New System.Drawing.Point(434, 218)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(123, 16)
        Me.Label14.TabIndex = 132
        Me.Label14.Text = "nibble swap hex "
        '
        'TextBox4
        '
        Me.TextBox4.Location = New System.Drawing.Point(969, 194)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(243, 20)
        Me.TextBox4.TabIndex = 131
        '
        'DataGridView2
        '
        Me.DataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.DataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView2.Location = New System.Drawing.Point(358, 254)
        Me.DataGridView2.Name = "DataGridView2"
        Me.DataGridView2.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken
        Me.DataGridView2.Size = New System.Drawing.Size(432, 370)
        Me.DataGridView2.TabIndex = 130
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(563, 215)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(278, 20)
        Me.TextBox3.TabIndex = 129
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(1161, 156)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(51, 20)
        Me.TextBox2.TabIndex = 128
        '
        'keyforsbox
        '
        Me.keyforsbox.Location = New System.Drawing.Point(332, 41)
        Me.keyforsbox.Name = "keyforsbox"
        Me.keyforsbox.Size = New System.Drawing.Size(823, 20)
        Me.keyforsbox.TabIndex = 127
        '
        'cyphertext
        '
        Me.cyphertext.Location = New System.Drawing.Point(124, 73)
        Me.cyphertext.MaxLength = 16
        Me.cyphertext.Name = "cyphertext"
        Me.cyphertext.Size = New System.Drawing.Size(163, 20)
        Me.cyphertext.TabIndex = 125
        '
        'textinbinary
        '
        Me.textinbinary.Location = New System.Drawing.Point(304, 73)
        Me.textinbinary.Name = "textinbinary"
        Me.textinbinary.Size = New System.Drawing.Size(836, 20)
        Me.textinbinary.TabIndex = 124
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle))
        Me.Label11.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label11.Location = New System.Drawing.Point(-3, 73)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(79, 16)
        Me.Label11.TabIndex = 123
        Me.Label11.Text = "cipher text"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle))
        Me.Label10.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label10.Location = New System.Drawing.Point(-4, 215)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(112, 16)
        Me.Label10.TabIndex = 122
        Me.Label10.Text = "hex of right half"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle))
        Me.Label8.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label8.Location = New System.Drawing.Point(435, 132)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(255, 16)
        Me.Label8.TabIndex = 121
        Me.Label8.Text = "rotate key left according to the ones"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle))
        Me.Label9.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label9.Location = New System.Drawing.Point(199, 134)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(163, 18)
        Me.Label9.TabIndex = 120
        Me.Label9.Text = "count ones from key"
        '
        'ListBox1
        '
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.Location = New System.Drawing.Point(1218, 156)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(65, 95)
        Me.ListBox1.TabIndex = 119
        '
        'hexaofxor
        '
        Me.hexaofxor.Location = New System.Drawing.Point(114, 215)
        Me.hexaofxor.Name = "hexaofxor"
        Me.hexaofxor.Size = New System.Drawing.Size(317, 20)
        Me.hexaofxor.TabIndex = 118
        '
        'leftrotatedstring
        '
        Me.leftrotatedstring.Location = New System.Drawing.Point(696, 132)
        Me.leftrotatedstring.Name = "leftrotatedstring"
        Me.leftrotatedstring.Size = New System.Drawing.Size(727, 20)
        Me.leftrotatedstring.TabIndex = 117
        '
        'totalones
        '
        Me.totalones.Location = New System.Drawing.Point(368, 132)
        Me.totalones.Name = "totalones"
        Me.totalones.Size = New System.Drawing.Size(61, 20)
        Me.totalones.TabIndex = 116
        '
        'prevrighttoleft
        '
        Me.prevrighttoleft.Location = New System.Drawing.Point(77, 190)
        Me.prevrighttoleft.Name = "prevrighttoleft"
        Me.prevrighttoleft.Size = New System.Drawing.Size(352, 20)
        Me.prevrighttoleft.TabIndex = 115
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle))
        Me.Label7.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label7.Location = New System.Drawing.Point(819, 190)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(104, 16)
        Me.Label7.TabIndex = 114
        Me.Label7.Text = "Result of XOR"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle))
        Me.Label6.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label6.Location = New System.Drawing.Point(0, 194)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(65, 16)
        Me.Label6.TabIndex = 113
        Me.Label6.Text = "pre right"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle))
        Me.Label5.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label5.Location = New System.Drawing.Point(1085, 16)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(85, 16)
        Me.Label5.TabIndex = 112
        Me.Label5.Text = "Master Key"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle))
        Me.Label4.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label4.Location = New System.Drawing.Point(819, 165)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(91, 16)
        Me.Label4.TabIndex = 111
        Me.Label4.Text = "right 64 bits "
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle))
        Me.Label3.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label3.Location = New System.Drawing.Point(-6, 165)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(78, 16)
        Me.Label3.TabIndex = 110
        Me.Label3.Text = "left 64 bits"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle))
        Me.Label2.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label2.Location = New System.Drawing.Point(-5, -1)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(247, 33)
        Me.Label2.TabIndex = 109
        Me.Label2.Text = "Decryption Form"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle))
        Me.Label1.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label1.Location = New System.Drawing.Point(-2, 45)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(159, 16)
        Me.Label1.TabIndex = 108
        Me.Label1.Text = "Input Key of 16 charac"
        '
        'xorof2halves
        '
        Me.xorof2halves.Location = New System.Drawing.Point(435, 190)
        Me.xorof2halves.Name = "xorof2halves"
        Me.xorof2halves.Size = New System.Drawing.Size(378, 20)
        Me.xorof2halves.TabIndex = 107
        '
        'righthalf
        '
        Me.righthalf.Location = New System.Drawing.Point(435, 164)
        Me.righthalf.Name = "righthalf"
        Me.righthalf.Size = New System.Drawing.Size(378, 20)
        Me.righthalf.TabIndex = 106
        Me.righthalf.Text = " "
        '
        'lefthalf
        '
        Me.lefthalf.Location = New System.Drawing.Point(77, 164)
        Me.lefthalf.Name = "lefthalf"
        Me.lefthalf.Size = New System.Drawing.Size(352, 20)
        Me.lefthalf.TabIndex = 105
        '
        'keyinbinary
        '
        Me.keyinbinary.Location = New System.Drawing.Point(246, 12)
        Me.keyinbinary.MaxLength = 128
        Me.keyinbinary.Name = "keyinbinary"
        Me.keyinbinary.Size = New System.Drawing.Size(832, 20)
        Me.keyinbinary.TabIndex = 104
        '
        'keyinput
        '
        Me.keyinput.Location = New System.Drawing.Point(163, 41)
        Me.keyinput.MaxLength = 16
        Me.keyinput.Name = "keyinput"
        Me.keyinput.Size = New System.Drawing.Size(160, 20)
        Me.keyinput.TabIndex = 103
        '
        'plaintext
        '
        Me.plaintext.Location = New System.Drawing.Point(13, 368)
        Me.plaintext.Name = "plaintext"
        Me.plaintext.Size = New System.Drawing.Size(310, 20)
        Me.plaintext.TabIndex = 152
        '
        'decryptionform
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1349, 721)
        Me.Controls.Add(Me.plaintext)
        Me.Controls.Add(Me.Label22)
        Me.Controls.Add(Me.Label21)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label20)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.DataGridView3)
        Me.Controls.Add(Me.keyinhex)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.TextBox4)
        Me.Controls.Add(Me.DataGridView2)
        Me.Controls.Add(Me.TextBox3)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.keyforsbox)
        Me.Controls.Add(Me.cyphertext)
        Me.Controls.Add(Me.textinbinary)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.ListBox1)
        Me.Controls.Add(Me.hexaofxor)
        Me.Controls.Add(Me.leftrotatedstring)
        Me.Controls.Add(Me.totalones)
        Me.Controls.Add(Me.prevrighttoleft)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.xorof2halves)
        Me.Controls.Add(Me.righthalf)
        Me.Controls.Add(Me.lefthalf)
        Me.Controls.Add(Me.keyinbinary)
        Me.Controls.Add(Me.keyinput)
        Me.Name = "decryptionform"
        Me.Text = "decryption-form"
        CType(Me.DataGridView3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label22 As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents Button3 As Button
    Friend WithEvents DataGridView3 As DataGridView
    Friend WithEvents keyinhex As TextBox
    Friend WithEvents Label15 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents TextBox4 As TextBox
    Friend WithEvents DataGridView2 As DataGridView
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents keyforsbox As TextBox
    Friend WithEvents cyphertext As TextBox
    Friend WithEvents textinbinary As TextBox
    Friend WithEvents Label11 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents ListBox1 As ListBox
    Friend WithEvents hexaofxor As TextBox
    Friend WithEvents leftrotatedstring As TextBox
    Friend WithEvents totalones As TextBox
    Friend WithEvents prevrighttoleft As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents xorof2halves As TextBox
    Friend WithEvents righthalf As TextBox
    Friend WithEvents lefthalf As TextBox
    Friend WithEvents keyinbinary As TextBox
    Friend WithEvents keyinput As TextBox
    Friend WithEvents plaintext As TextBox
End Class
