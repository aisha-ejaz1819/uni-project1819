﻿Public Class Form1

    Public Function Bin_To_Dec(ByVal Bin As String)
        Dim dec As Double = Nothing
        Dim length As Integer = Len(Bin)
        Dim temp As Integer = Nothing
        Dim x As Integer = Nothing
        For x = 1 To length
            temp = Val(Mid(Bin, length, 1))
            length = length - 1
            If temp <> "0" Then
                dec += (2 ^ (x - 1))
            End If
        Next
        MessageBox.Show(dec)
    End Function




    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Dim Temp As String = ""
        Dim txtBuilder As New System.Text.StringBuilder
        For Each Character As Byte In System.Text.ASCIIEncoding.ASCII.GetBytes(TextBox1.Text)
            txtBuilder.Append(Convert.ToString(Character, 2).PadLeft(8, "0"))
        Next
        Temp = txtBuilder.ToString.Substring(0, txtBuilder.ToString.Length - 0)
        TextBox2.Text = Temp
        TextBox11.Text = TextBox2.Text.Substring(32, 32)





    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        TextBox8.Text = TextBox4.Text
        For i = 0 To 63
            If (TextBox3.Text.Substring(i, 1) = TextBox4.Text.Substring(i, 1)) Then
                TextBox5.Text += "1"
            Else
                TextBox5.Text += "0"

            End If
        Next

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click

        TextBox7.Text = Bin_To_Dec(TextBox11.Text)
        MessageBox.Show(Convert.ToDecimal(Bin_To_Dec(TextBox11.Text)))

    End Sub

    Dim count As Integer = Nothing


    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click

        For i = 0 To 127
            If (TextBox2.Text.Substring(i, 1) = "1") Then
                count += 1
            End If
        Next
        TextBox6.Text = count

    End Sub

    Private Sub TextBox8_TextChanged(sender As Object, e As EventArgs) Handles TextBox8.TextChanged

    End Sub

    Private Sub TextBox14_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub TextBox13_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Dim sb As New System.Text.StringBuilder
        Dim temp1 As String = ""
        Dim binary As String = TextBox5.Text
        For pos As Integer = 0 To binary.Length - 8 Step 8
            sb.Append(Convert.ToByte(binary.Substring(pos, 8), 2).ToString("X2"))
        Next
        temp1 = sb.ToString.Substring(0, sb.ToString.Length - 0)
        TextBox10.Text = temp1
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        Dim leftsh1 As String
        Dim leftsh2 As String
        leftsh1 = TextBox2.Text.Substring(0, count)
        leftsh2 = TextBox2.Text.Substring(count, 128 - count)
        TextBox9.Text = leftsh2 + leftsh1
        TextBox3.Text = TextBox9.Text.Substring(0, 64)
        TextBox4.Text = TextBox9.Text.Substring(64, 64)

    End Sub

    Private Sub TextBox11_TextChanged(sender As Object, e As EventArgs) Handles TextBox11.TextChanged

    End Sub

    Private Sub TextBox7_TextChanged(sender As Object, e As EventArgs) Handles TextBox7.TextChanged

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub




    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        Dim strarray(8) As String
        Dim j As Integer = Nothing
        j = 0
        For counter = 0 To 7

            strarray(counter) = TextBox10.Text.Substring(j, 2)
            j = j + 2
            ListBox1.Items.Add(strarray(counter))
        Next
    End Sub

End Class