﻿Public Class decryptionform

    ' Private Sub decryptionform_Load(sender As Object, e As EventArgs) Handles MyBase.Load
    'Public Class decryptionForm
    Public Property PassCypher As String
    Public Property PassKey As String
    Public Function CharTobits(ByVal temp As String)
            Dim txtBuilder As New System.Text.StringBuilder
            For Each Character As Byte In System.Text.ASCIIEncoding.ASCII.GetBytes(temp)
                txtBuilder.Append(Convert.ToString(Character, 2).PadLeft(8, "0"))
            Next
            Dim keytobits As String = txtBuilder.ToString.Substring(0, txtBuilder.ToString.Length - 0)
            Return keytobits
        End Function

        Public Function BinaryToHexa(ByVal binary As String)
            Dim sb As New System.Text.StringBuilder
            Dim temp1 As String = ""
            For pos As Integer = 0 To binary.Length - 8 Step 8
                sb.Append(Convert.ToByte(binary.Substring(pos, 8), 2).ToString("X2"))
            Next
            temp1 = sb.ToString.Substring(0, sb.ToString.Length - 0)
            Return temp1
        End Function

        Public Function HexaToBinary(ByVal hexstring As String)
            Dim bin As New Text.StringBuilder
            For Each ch As Char In hexstring
                bin.Append(Convert.ToString(Convert.ToInt32(ch, 16), 2).PadLeft(4, "0"c))
            Next
            Return bin.ToString
        End Function

        Public Function NibbleSwap(ByVal swap As String)
            Dim swap1 As String = ""
            Dim swap2 As String = ""
            Dim output As String = ""
            Dim nswap(8) As String
            Dim p As Integer
            p = 0
            For z = 0 To 7
                swap1 = swap.Substring(p, 1)
                swap2 = swap.Substring(p + 1, 1)
                nswap(z) = swap2 + swap1
                output = output & nswap(z)
                p = p + 2
            Next
            Return output
        End Function

        Public Function Byte_Sub(ByVal Hexval As String)
            Dim j As Integer
            j = 0
            Dim mask(Len(Hexval) / 2) As String
            Dim d As String = ""
            Dim x As Integer
            For x = 0 To (Len(Hexval) / 2) - 1
                Dim s As Integer = Nothing
                Dim t As Integer = Nothing
                Dim a As String = ""
                Dim b As String = ""
                a = Hexval.Substring(j, 1)
                b = Hexval.Substring(j + 1, 1)
                If a = "A" Then
                    a = 10
                ElseIf a = "B" Then
                    a = 11
                ElseIf a = "C" Then
                    a = 12
                ElseIf a = "D" Then
                    a = 13
                ElseIf a = "E" Then
                    a = 14
                ElseIf a = "F" Then
                    a = 15
                End If
                If b = "A" Then
                    b = 10
                ElseIf b = "B" Then
                    b = 11
                ElseIf b = "C" Then
                    b = 12
                ElseIf b = "D" Then
                    b = 13
                ElseIf b = "E" Then
                    b = 14
                ElseIf b = "F" Then
                    b = 15
                End If
                s = a
                t = b
                mask(x) = DataGridView2.Rows(s).Cells(t).Value
                d = d & mask(x)
                j = j + 2
            Next
            Return d
        End Function

        Public Function InvByte_Sub(ByVal Hexval As String)
            Dim j As Integer
            j = 0
            Dim mask(Len(Hexval) / 2) As String
            Dim d As String = ""
            Dim x As Integer
            For x = 0 To (Len(Hexval) / 2) - 1
                Dim s As Integer = Nothing
                Dim t As Integer = Nothing
                Dim a As String = ""
                Dim b As String = ""
                a = Hexval.Substring(j, 1)
                b = Hexval.Substring(j + 1, 1)
                If a = "A" Then
                    a = 10
                ElseIf a = "B" Then
                    a = 11
                ElseIf a = "C" Then
                    a = 12
                ElseIf a = "D" Then
                    a = 13
                ElseIf a = "E" Then
                    a = 14
                ElseIf a = "F" Then
                    a = 15
                End If
                If b = "A" Then
                    b = 10
                ElseIf b = "B" Then
                    b = 11
                ElseIf b = "C" Then
                    b = 12
                ElseIf b = "D" Then
                    b = 13
                ElseIf b = "E" Then
                    b = 14
                ElseIf b = "F" Then
                    b = 15
                End If
                s = a
                t = b
                mask(x) = DataGridView3.Rows(s).Cells(t).Value
                d = d & mask(x)
                j = j + 2
            Next
            Return d
        End Function

        Public Function GenKey(ByVal myKey As String)
            Dim W(43)
            Dim tmp
            Dim i As Integer
            Dim tmp2 As String = ""
            Dim Rcon As String
            tmp = myKey
            W(0) = Microsoft.VisualBasic.Left(myKey, 8)
            W(1) = Mid(myKey, 9, 8)
            W(2) = Mid(myKey, 17, 8)
            W(3) = Microsoft.VisualBasic.Right(myKey, 8)
1:
            i = i + 4
            Rcon = Hex(BinToDec("1" & Nfois("0", Int(i / 4) - 1))) : If Len(Rcon) = 1 Then Rcon = "0" & Rcon & "000000" Else Rcon = Rcon & "000000"
            If i = 36 Then Rcon = "1B000000" Else
            If i = 40 Then Rcon = "36000000" Else
            W(i) = XXOR_HEX(XXOR_HEX(Byte_Sub(FxPermu(W(i - 1), "01020300")), W(i - 4)), Rcon)
            W(i + 1) = XXOR_HEX(W(i), W(i - 3))
            W(i + 2) = XXOR_HEX(W(i + 1), W(i - 2))
            W(i + 3) = XXOR_HEX(W(i + 2), W(i - 1))
            If i + 3 <> 43 Then GoTo 1 Else
            For x = 0 To 43
                tmp2 = tmp2 & W(x)
            Next

            GenKey = tmp2
        End Function

        Public Function BinToDec(BinNum) As String
            If Len(BinNum) <> 8 Then BinNum = Nfois("0", 8 - Len(BinNum)) & BinNum Else
            Dim j
            For i = 8 To 1 Step -1
                j = j + Val(Mid(BinNum, i, 1)) * 2 ^ (8 - i)
            Next
            BinToDec = j
        End Function

        Public Function FxPermu(mystr, PERMU_table) As String
            Dim mytab() As String
            Dim b, bb, c As String
            Dim d As String = ""
            ReDim mytab(Len(mystr) / 2)
            For a = 1 To Len(mystr) / 2
                b = Val("&h" & Mid(PERMU_table, 2 * a - 1, 2))
                bb = 2 * b + 1
                c = Mid(mystr, bb, 2)
                d = d & c
            Next
            FxPermu = d
        End Function

        Public Function fx_GF28(myINPUT, Algo_TYPE)
            Dim a0, a1, a2, a3, b0, b1, b2, b3, c
            For i = 1 To Len(myINPUT) / 2 Step 4
                a0 = Mid(myINPUT, i * 2 - 1, 2)
                a1 = Mid(myINPUT, i * 2 + 1, 2)
                a2 = Mid(myINPUT, i * 2 + 3, 2)
                a3 = Mid(myINPUT, i * 2 + 5, 2)
                Select Case Algo_TYPE
                    Case 0
                        b0 = Hex(Val("&h" & GF28("02", a0)) Xor Val("&h" & GF28("03", a1)) Xor Val("&h" & a2) Xor Val("&h" & a3))
                        b1 = Hex(Val("&h" & a0) Xor Val("&h" & GF28("02", a1)) Xor Val("&h" & GF28("03", a2)) Xor Val("&h" & a3))
                        b2 = Hex(Val("&h" & a0) Xor Val("&h" & a1) Xor Val("&h" & GF28("02", a2)) Xor Val("&h" & GF28("03", a3)))
                        b3 = Hex(Val("&h" & GF28("03", a0)) Xor Val("&h" & a1) Xor Val("&h" & a2) Xor Val("&h" & GF28("02", a3)))
                    Case 1
                        b0 = Hex(Val("&h" & GF28("0E", a0)) Xor Val("&h" & GF28("0B", a1)) Xor Val("&h" & GF28("0D", a2)) Xor Val("&h" & GF28("09", a3)))
                        b1 = Hex(Val("&h" & GF28("09", a0)) Xor Val("&h" & GF28("0E", a1)) Xor Val("&h" & GF28("0B", a2)) Xor Val("&h" & GF28("0D", a3)))
                        b2 = Hex(Val("&h" & GF28("0D", a0)) Xor Val("&h" & GF28("09", a1)) Xor Val("&h" & GF28("0E", a2)) Xor Val("&h" & GF28("0B", a3)))
                        b3 = Hex(Val("&h" & GF28("0B", a0)) Xor Val("&h" & GF28("0D", a1)) Xor Val("&h" & GF28("09", a2)) Xor Val("&h" & GF28("0E", a3)))
                End Select

                If Len(b0) = 1 Then b0 = "0" & b0 Else
                If Len(b1) = 1 Then b1 = "0" & b1 Else
                If Len(b2) = 1 Then b2 = "0" & b2 Else
                If Len(b3) = 1 Then b3 = "0" & b3 Else
                c = c & b0 & b1 & b2 & b3
            Next
            fx_GF28 = c
        End Function

        Public Function GF28(FirstByte, SecondByte)
            Dim tab1(,)
            Dim tab2() As String
            Dim a, b, c, d, nbr1, nbr2, nbr3, str_nbr, str_nbr2, str_nbr3, y, step1, step2, XOR_const, xor_str, myHEX
            Dim loc1, loc2, lnSTR
            Dim After_XOR
            a = ToBin(Val("&h" & FirstByte))
            b = ToBin(Val("&h" & SecondByte))
            If a = 0 Or b = 0 Then GF28 = "00" : GoTo 3 Else 'FAUX
            c = toPOS(a)
            d = toPOS(b)
            ReDim tab1(Len(c) - 1, Len(d) - 1)
            For i = 0 To Len(c) - 1
                nbr1 = Val(Mid(c, i + 1, 1))
                For j = 0 To Len(d) - 1
                    nbr2 = Val(Mid(d, j + 1, 1))
                    nbr3 = nbr1 + nbr2
                    str_nbr = LTrim(Str(nbr3))
                    If Len(str_nbr) = 1 Then str_nbr = "0" & str_nbr Else
                    str_nbr2 = str_nbr2 & str_nbr
                Next
            Next
            GF28 = str_nbr2
1:
            For x = 1 To Len(str_nbr2) / 2
                y = Mid(str_nbr2, x * 2 - 1, 2)
                loc1 = InStr(str_nbr2, y)
                loc2 = InStrRev(str_nbr2, y)
                If (loc1 <> loc2) And (loc1 Mod 2 = 1) And (loc2 Mod 2 = 1) Then
                    str_nbr3 = Microsoft.VisualBasic.Left(str_nbr2, loc1 - 1) & Mid(str_nbr2, loc1 + 2, loc2 - loc1 - 2) & Microsoft.VisualBasic.Right(str_nbr2, Len(str_nbr2) - loc2 - 1)
                    str_nbr2 = str_nbr3
                    GoTo 1
                End If
            Next
            lnSTR = Val(Microsoft.VisualBasic.Left(str_nbr2, 2))
            ReDim tab2(lnSTR)
            For x = 1 To Len(str_nbr2) / 2
                y = Val(Mid(str_nbr2, x * 2 - 1, 2))
                tab2(y) = 1
            Next
            For x = lnSTR To 0 Step -1
                If tab2(x) = "" Then tab2(x) = 0 Else
                step1 = step1 & tab2(x)
            Next
2:
            If Len(step1) > 8 Then
                XOR_const = "100011011" 'x^8+x^4+x^3+x+1
                xor_str = XXOR(XOR_const, step1)

                If Val(xor_str) <> 0 Then After_XOR = Microsoft.VisualBasic.Right(xor_str, Len(xor_str) - InStr(xor_str, "1") + 1) & Microsoft.VisualBasic.Right(step1, Len(step1) - Len(xor_str)) Else After_XOR = Microsoft.VisualBasic.Right(step1, Len(step1) - Len(xor_str))
                step1 = After_XOR
                GoTo 2
            End If
            step2 = step1
            myHEX = Hex(BinToDec(step2))
            If Len(myHEX) = 1 Then myHEX = "0" & myHEX Else
3:
            GF28 = myHEX
        End Function

        Public Function ToBin(n) As String

            Do Until n = 0
                If (n Mod 2) Then ToBin = "1" & ToBin Else ToBin = "0" & ToBin
                n = n \ 2
            Loop
            If Len(ToBin) <> 8 Then ToBin = Nfois("0", 8 - Len(ToBin)) & ToBin Else

            Return ToBin
        End Function

        Public Function Nfois(a, n) As String
            Dim j
            For i = 1 To n
                j = j & a
            Next
            Nfois = j
        End Function

        Public Function toPOS(nBIN) As String
            Dim a, b
            For i = 1 To 8
                a = Mid(nBIN, i, 1)
                If a = 1 Then b = b & (8 - i)
            Next
            toPOS = b
        End Function

        Public Function XXOR(Small, Big) As String
            Dim c, d, e, ee
            For i = 1 To Len(Small)
                c = Val(Mid(Small, i, 1))
                d = Val(Mid(Big, i, 1))
                e = c Xor d
                ee = ee & LTrim(Str(e))
            Next
            XXOR = ee
        End Function

        Public Function XXOR_HEX(HEX1, HEX2)
            Dim a, b, c, d
            For i = 1 To Len(HEX1) / 2
                a = Val("&h" & Mid(HEX1, 2 * i - 1, 2))
                b = Val("&h" & Mid(HEX2, 2 * i - 1, 2))
                c = Hex(a Xor b) : If Len(c) = 1 Then c = "0" & c Else
                d = d & c
            Next
            XXOR_HEX = d
        End Function

        Public Function AES_Decrypt(CipherText, AES_KEY)


            Dim ExtendedKey, Key_i, DATA_i, After_XOR, InvSub, ShiftRows, ShiftRows_TAB, final, MixColumns
            Dim i
            i = 0
            ExtendedKey = GenKey(AES_KEY)
            DATA_i = CipherText

1:

            i = i + 1
            Key_i = Mid(ExtendedKey, Len(ExtendedKey) - 32 * i + 1, 32)

            After_XOR = XXOR_HEX(DATA_i, Key_i)
            If i = 1 Then MixColumns = After_XOR Else MixColumns = fx_GF28(After_XOR, 1)

            ShiftRows_TAB = "000D0A0704010E0B0805020F0C090603"
            ShiftRows = FxPermu(MixColumns, ShiftRows_TAB)

            InvSub = InvByte_Sub(ShiftRows)

            If i <= 9 Then DATA_i = InvSub : GoTo 1 Else

            final = XXOR_HEX(InvSub, Microsoft.VisualBasic.Left(ExtendedKey, 32))

            AES_Decrypt = final

        End Function


    Private Sub Decryption_Form_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        keyinput.Text = PassKey
        cyphertext.Text = PassCypher
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs)
        'Dim TimerStart As DateTime
        'TimerStart = Now
        'Dim x, y As Integer

        'Dim strarray(256) As String
        'Dim sarray(256) As String
        'Dim sbox(256) As String
        'Dim a, b, c, r As Integer

        'Dim j As Integer = Nothing
        'b = 0
        'a = 0
        'DataGridView2.ColumnCount = 16
        'DataGridView2.RowCount = 16
        'DataGridView3.ColumnCount = 16
        'DataGridView3.RowCount = 16
        'Dim rotcount As Integer = Nothing

        'For y = 0 To 300
        '    Dim stoutput As String = ""
        '    rotcount = 0
        '    For i = 0 To 127
        '        If (keyforsbox.Text.Substring(i, 1) = "1") Then
        '            rotcount += 1
        '        End If
        '    Next
        '    totalones.Text = rotcount
        '    Dim leftsh1 As String = ""
        '    Dim leftsh2 As String = ""
        '    leftsh1 = keyforsbox.Text.Substring(0, rotcount)
        '    leftsh2 = keyforsbox.Text.Substring(rotcount, 128 - rotcount)
        '    leftrotatedstring.Text = ""
        '    leftrotatedstring.Text = leftsh2 + leftsh1
        '    lefthalf.Text = ""
        '    righthalf.Text = ""
        '    lefthalf.Text = leftrotatedstring.Text.Substring(0, 64)
        '    righthalf.Text = leftrotatedstring.Text.Substring(64, 64)
        '    prevrighttoleft.Text = ""
        '    prevrighttoleft.Text = righthalf.Text
        '    xorof2halves.Text = ""
        '    For i = 0 To 63
        '        If (lefthalf.Text.Substring(i, 1) = righthalf.Text.Substring(i, 1)) Then
        '            xorof2halves.Text += "0"
        '        Else
        '            xorof2halves.Text += "1"

        '        End If
        '    Next

        '    hexaofxor.Text = ""
        '    hexaofxor.Text = BinaryToHexa(xorof2halves.Text)
        '    TextBox3.Text = ""
        '    TextBox3.Text = NibbleSwap(hexaofxor.Text)

        '    TextBox4.Text = ""
        '    TextBox4.Text = HexaToBinary(TextBox3.Text)
        '    keyforsbox.Text = ""
        '    keyforsbox.Text = prevrighttoleft.Text + TextBox4.Text
        '    For x = 0 To 7
        '        strarray(x) = TextBox3.Text.Substring(j, 2)

        '        j = j + 2
        '        If j = 16 Then
        '            j = 0
        '        End If
        '        c = 0
        '        For r = 0 To b
        '            c = c + 1
        '            If strarray(x) = sbox(r) Then
        '                Exit For
        '            End If
        '        Next
        '        If c = r Then
        '            sbox(b) = strarray(x)
        '            ListBox1.Items.Add(sbox(b))
        '            b = b + 1

        '            If b > 255 Then
        '                Exit For
        '                Exit For
        '            End If

        '        End If
        '    Next

        'Next

        'TextBox2.Text = b
        'Dim s As Integer
        'Dim t As Integer
        's = 0
        't = 0

        'For ct = 0 To ListBox1.Items.Count - 1
        '    DataGridView2.CurrentCell = DataGridView2(s, t)
        '    DataGridView2.Rows(t).Cells(s).Value = ListBox1.Items(ct)
        '    s = s + 1
        '    If s > 15 Then
        '        t = t + 1
        '        s = 0
        '    End If
        '    If t > 15 Then
        '        Exit For
        '    End If
        'Next

        'For row = 0 To 15

        '    For col = 0 To 15
        '        Dim Sinv, Sinv1, Sinv2 As String
        '        Sinv = DataGridView2.Rows(row).Cells(col).Value
        '        Sinv1 = Microsoft.VisualBasic.Left(Sinv, 1)
        '        Sinv2 = Microsoft.VisualBasic.Right(Sinv, 1)
        '        If Sinv1 = "A" Then
        '            Sinv1 = 10
        '        ElseIf Sinv1 = "B" Then
        '            Sinv1 = 11
        '        ElseIf Sinv1 = "C" Then
        '            Sinv1 = 12
        '        ElseIf Sinv1 = "D" Then
        '            Sinv1 = 13
        '        ElseIf Sinv1 = "E" Then
        '            Sinv1 = 14
        '        ElseIf Sinv1 = "F" Then
        '            Sinv1 = 15
        '        End If

        '        If Sinv2 = "A" Then
        '            Sinv2 = 10
        '        ElseIf Sinv2 = "B" Then
        '            Sinv2 = 11
        '        ElseIf Sinv2 = "C" Then
        '            Sinv2 = 12
        '        ElseIf Sinv2 = "D" Then
        '            Sinv2 = 13
        '        ElseIf Sinv2 = "E" Then
        '            Sinv2 = 14
        '        ElseIf Sinv2 = "F" Then
        '            Sinv2 = 15
        '        End If


        '        Dim r2, c2 As Integer
        '        r2 = Sinv1
        '        c2 = Sinv2

        '        Sinv1 = row
        '        Sinv2 = col
        '        If row = 10 Then
        '            Sinv1 = "A"
        '        ElseIf row = 11 Then
        '            Sinv1 = "B"
        '        ElseIf row = 12 Then
        '            Sinv1 = "C"
        '        ElseIf row = 13 Then
        '            Sinv1 = "D"
        '        ElseIf row = 14 Then
        '            Sinv1 = "E"
        '        ElseIf row = 15 Then
        '            Sinv1 = "F"
        '        End If

        '        If col = 10 Then
        '            Sinv2 = "A"
        '        ElseIf col = 11 Then
        '            Sinv2 = "B"
        '        ElseIf col = 12 Then
        '            Sinv2 = "C"
        '        ElseIf col = 13 Then
        '            Sinv2 = "D"
        '        ElseIf col = 14 Then
        '            Sinv2 = "E"
        '        ElseIf col = 15 Then
        '            Sinv2 = "F"
        '        End If
        '        Sinv = Sinv1 & Sinv2
        '        DataGridView3.Rows(r2).Cells(c2).Value = Sinv
        '    Next

        'Next
        'Dim st As String
        'st = AES_Decrypt(cyphertext.Text, keyinhex.Text)
        'Dim com As String
        'For x = 0 To st.Length - 1 Step 2
        '    Dim k As String = st.Substring(x, 2)
        '    com &= System.Convert.ToChar(System.Convert.ToUInt32(k, 16)).ToString()
        'Next
        'plaintext.Text = com
        'Dim TimeSpent As System.TimeSpan
        'TimeSpent = Now.Subtract(TimerStart)
        'MsgBox(TimeSpent.TotalSeconds & " seconds spent on this task")
    End Sub

    Private Sub Keyinput_TextChanged(sender As Object, e As EventArgs) Handles keyinput.TextChanged
        keyinput.MaxLength = 16

        keyinbinary.Text = CharTobits(keyinput.Text)
        keyforsbox.Text = keyinbinary.Text
        keyinhex.Text = BinaryToHexa(keyinbinary.Text)
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim TimerStart As DateTime
        TimerStart = Now
        Dim x, y As Integer

        Dim strarray(256) As String
        Dim sarray(256) As String
        Dim sbox(256) As String
        Dim a, b, c, r As Integer

        Dim j As Integer = Nothing
        b = 0
        a = 0
        DataGridView2.ColumnCount = 16
        DataGridView2.RowCount = 16
        DataGridView3.ColumnCount = 16
        DataGridView3.RowCount = 16
        Dim rotcount As Integer = Nothing

        For y = 0 To 300
            Dim stoutput As String = ""
            rotcount = 0
            For i = 0 To 127
                If (keyforsbox.Text.Substring(i, 1) = "1") Then
                    rotcount += 1
                End If
            Next
            totalones.Text = rotcount
            Dim leftsh1 As String = ""
            Dim leftsh2 As String = ""
            leftsh1 = keyforsbox.Text.Substring(0, rotcount)
            leftsh2 = keyforsbox.Text.Substring(rotcount, 128 - rotcount)
            leftrotatedstring.Text = ""
            leftrotatedstring.Text = leftsh2 + leftsh1
            lefthalf.Text = ""
            righthalf.Text = ""
            lefthalf.Text = leftrotatedstring.Text.Substring(0, 64)
            righthalf.Text = leftrotatedstring.Text.Substring(64, 64)
            prevrighttoleft.Text = ""
            prevrighttoleft.Text = righthalf.Text
            xorof2halves.Text = ""
            For i = 0 To 63
                If (lefthalf.Text.Substring(i, 1) = righthalf.Text.Substring(i, 1)) Then
                    xorof2halves.Text += "0"
                Else
                    xorof2halves.Text += "1"

                End If
            Next

            hexaofxor.Text = ""
            hexaofxor.Text = BinaryToHexa(xorof2halves.Text)
            TextBox3.Text = ""
            TextBox3.Text = NibbleSwap(hexaofxor.Text)

            TextBox4.Text = ""
            TextBox4.Text = HexaToBinary(TextBox3.Text)
            keyforsbox.Text = ""
            keyforsbox.Text = prevrighttoleft.Text + TextBox4.Text
            For x = 0 To 7
                strarray(x) = TextBox3.Text.Substring(j, 2)

                j = j + 2
                If j = 16 Then
                    j = 0
                End If
                c = 0
                For r = 0 To b
                    c = c + 1
                    If strarray(x) = sbox(r) Then
                        Exit For
                    End If
                Next
                If c = r Then
                    sbox(b) = strarray(x)
                    ListBox1.Items.Add(sbox(b))
                    b = b + 1

                    If b > 255 Then
                        Exit For
                        Exit For
                    End If

                End If
            Next

        Next

        TextBox2.Text = b
        Dim s As Integer
        Dim t As Integer
        s = 0
        t = 0

        For ct = 0 To ListBox1.Items.Count - 1
            DataGridView2.CurrentCell = DataGridView2(s, t)
            DataGridView2.Rows(t).Cells(s).Value = ListBox1.Items(ct)
            s = s + 1
            If s > 15 Then
                t = t + 1
                s = 0
            End If
            If t > 15 Then
                Exit For
            End If
        Next

        For row = 0 To 15

            For col = 0 To 15
                Dim Sinv, Sinv1, Sinv2 As String
                Sinv = DataGridView2.Rows(row).Cells(col).Value
                Sinv1 = Microsoft.VisualBasic.Left(Sinv, 1)
                Sinv2 = Microsoft.VisualBasic.Right(Sinv, 1)
                If Sinv1 = "A" Then
                    Sinv1 = 10
                ElseIf Sinv1 = "B" Then
                    Sinv1 = 11
                ElseIf Sinv1 = "C" Then
                    Sinv1 = 12
                ElseIf Sinv1 = "D" Then
                    Sinv1 = 13
                ElseIf Sinv1 = "E" Then
                    Sinv1 = 14
                ElseIf Sinv1 = "F" Then
                    Sinv1 = 15
                End If

                If Sinv2 = "A" Then
                    Sinv2 = 10
                ElseIf Sinv2 = "B" Then
                    Sinv2 = 11
                ElseIf Sinv2 = "C" Then
                    Sinv2 = 12
                ElseIf Sinv2 = "D" Then
                    Sinv2 = 13
                ElseIf Sinv2 = "E" Then
                    Sinv2 = 14
                ElseIf Sinv2 = "F" Then
                    Sinv2 = 15
                End If


                Dim r2, c2 As Integer
                r2 = Sinv1
                c2 = Sinv2

                Sinv1 = row
                Sinv2 = col
                If row = 10 Then
                    Sinv1 = "A"
                ElseIf row = 11 Then
                    Sinv1 = "B"
                ElseIf row = 12 Then
                    Sinv1 = "C"
                ElseIf row = 13 Then
                    Sinv1 = "D"
                ElseIf row = 14 Then
                    Sinv1 = "E"
                ElseIf row = 15 Then
                    Sinv1 = "F"
                End If

                If col = 10 Then
                    Sinv2 = "A"
                ElseIf col = 11 Then
                    Sinv2 = "B"
                ElseIf col = 12 Then
                    Sinv2 = "C"
                ElseIf col = 13 Then
                    Sinv2 = "D"
                ElseIf col = 14 Then
                    Sinv2 = "E"
                ElseIf col = 15 Then
                    Sinv2 = "F"
                End If
                Sinv = Sinv1 & Sinv2
                DataGridView3.Rows(r2).Cells(c2).Value = Sinv
            Next

        Next
        Dim st As String
        st = AES_Decrypt(cyphertext.Text, keyinhex.Text)
        Dim com As String
        For x = 0 To st.Length - 1 Step 2
            Dim k As String = st.Substring(x, 2)
            com &= System.Convert.ToChar(System.Convert.ToUInt32(k, 16)).ToString()
        Next
        plaintext.Text = com
        Dim TimeSpent As System.TimeSpan
        TimeSpent = Now.Subtract(TimerStart)
        MsgBox(TimeSpent.TotalSeconds & " seconds spent on this task")
    End Sub


End Class




